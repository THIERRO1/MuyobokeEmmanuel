package construction;

public class MaterialDelivery extends ConstructionMaterial {

    public MaterialDelivery(String id, String name, double quantity, double balance) {
        this.contractorId = id;
        this.contractorName = name;
        this.materialQuantity = quantity;
        this.materialBalance = balance;
    }

    @Override
    public void receiveMaterial() {
        if (materialQuantity >= 1 && materialQuantity <= 10) {
            materialBalance += materialQuantity;
            System.out.println("✅ Material delivered successfully.");
            System.out.println("New Material Balance: " + materialBalance + " tons");
        } else {
            System.out.println("❌ Delivery failed! Quantity must be between 1 and 10 tons.");
        }
    }

    @Override
    public void useMaterial() {}
    @Override
    public void estimateCost() {}
}