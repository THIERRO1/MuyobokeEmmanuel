package construction;

public abstract class ConstructionMaterial {
    // common data for all materials
    protected String contractorId;
    protected String contractorName;
    protected double materialQuantity;
    protected double materialBalance;

    // abstract methods to be defined by children
    public abstract void receiveMaterial();
    public abstract void useMaterial();
    public abstract void estimateCost();
}