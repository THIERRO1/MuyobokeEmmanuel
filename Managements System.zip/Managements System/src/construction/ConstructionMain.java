package construction;

import java.util.Scanner;

public class ConstructionMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("👷 Welcome to Construction System");
        System.out.print("Enter Contractor ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Contractor Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Material Quantity (in tons): ");
        double qty = scanner.nextDouble();

        double initialBalance = 5; // assume we have 5 tons already

        MaterialDelivery delivery = new MaterialDelivery(id, name, qty, initialBalance);
        delivery.receiveMaterial();
    }
}