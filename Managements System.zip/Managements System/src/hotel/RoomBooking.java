package hotel;

public class RoomBooking extends HotelService {

    public RoomBooking(String id, String name, String type, int days, String status) {
        this.guestId = id;
        this.guestName = name;
        this.roomType = type.toUpperCase();
        this.stayDays = days;
        this.roomStatus = status.toUpperCase();
    }

    @Override
    public void bookRoom() {
        if (stayDays >= 1 && stayDays <= 30 && roomStatus.equals("AVAILABLE")) {
            roomStatus = "OCCUPIED";
            System.out.println(" Room booked successfully for " + guestName);
        } else {
            System.out.println(" Booking failed. Check stay days or room availability.");
        }
    }

    @Override
    public void checkoutGuest() {}
    @Override
    public void generateBill() {}
}