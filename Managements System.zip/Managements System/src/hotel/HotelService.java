package hotel;

public abstract class HotelService {
    protected String guestId;
    protected String guestName;
    protected String roomType; // STANDARD, DELUXE, SUITE
    protected int stayDays;
    protected String roomStatus; // AVAILABLE or OCCUPIED

    public abstract void bookRoom();
    public abstract void checkoutGuest();
    public abstract void generateBill();
}