package hotel;

import java.util.Scanner;

public class HotelMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println(" Welcome to Lemigo Hotel Booking");

        System.out.print("Enter Guest ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Guest Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Room Type (STANDARD / DELUXE / SUITE): ");
        String type = scanner.nextLine();

        System.out.print("Enter Number of Stay Days: ");
        int days = scanner.nextInt();
        scanner.nextLine(); // consume new line

        String status = "AVAILABLE"; // assume the room is available

        RoomBooking booking = new RoomBooking(id, name, type, days, status);
        booking.bookRoom();
    }
}