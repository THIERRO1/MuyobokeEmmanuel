package traffic;

import java.util.Scanner;

public class TrafficMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println(" Welcome to Rwanda Traffic Fine System");

        System.out.print("Enter Driver ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Driver Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Vehicle Plate: ");
        String plate = scanner.nextLine();

        System.out.print("Enter Violation Type (SPEEDING, RED_LIGHT, NO_HELMET, DUI): ");
        String violation = scanner.nextLine();

        ViolationEntry entry = new ViolationEntry(id, name, plate, violation);
        entry.recordViolation();
        entry.assessFine();
        entry.processPayment();
    }
}