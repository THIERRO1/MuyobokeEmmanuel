package traffic;

public class ViolationEntry extends TrafficRecord {

    public ViolationEntry(String id, String name, String plate, String violation) {
        this.driverId = id;
        this.driverName = name;
        this.vehiclePlate = plate;
        this.violationType = violation.toUpperCase();
        this.paymentStatus = "UNPAID";
    }

    @Override
    public void recordViolation() {
        if (violationType.equals("SPEEDING") || violationType.equals("RED_LIGHT") ||
                violationType.equals("NO_HELMET") || violationType.equals("DUI")) {
            System.out.println("Violation recorded for " + driverName);
        } else {
            System.out.println(" Unknown violation type.");
        }
    }

    @Override
    public void assessFine() {
        switch (violationType) {
            case "SPEEDING":
                fineAmount = 50000;
                break;
            case "RED_LIGHT":
                fineAmount = 80000;
                break;
            case "NO_HELMET":
                fineAmount = 30000;
                break;
            case "DUI":
                fineAmount = 150000;
                break;
            default:
                System.out.println(" Cannot assess fine: invalid violation.");
                return;
        }

        System.out.println("🚔 Fine for " + violationType + ": " + fineAmount + " RWF");
    }

    @Override
    public void processPayment() {
        if (paymentStatus.equals("UNPAID")) {
            paymentStatus = "PAID";
            System.out.println("Payment received for driver: " + driverName);
            System.out.println("Amount Paid: " + fineAmount + " RWF");
        } else {
            System.out.println(" Payment already made.");
        }
    }
}